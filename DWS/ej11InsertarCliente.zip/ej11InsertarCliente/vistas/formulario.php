<form action="" method="post">
	dniCliente: <input type="text" name="dniCliente"><br>
	nombre: <input type="text" name="nombre"><br>
	direccion: <input type="text" name="direccion"><br>
	email: <input type="text" name="email"><br>
	pwd: <input type="text" name="pwd">	<br>
	<input type="submit" name="enviar"><br>
</form>