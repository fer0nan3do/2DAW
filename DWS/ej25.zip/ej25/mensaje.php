<?php
echo $dato;