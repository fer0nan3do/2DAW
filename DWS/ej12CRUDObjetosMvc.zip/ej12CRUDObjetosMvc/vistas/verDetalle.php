<?php

foreach ($dato as $key => $value) 
		echo "$key: $value <br>";
	
