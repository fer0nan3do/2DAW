<?php

echo "<form action='' method='post'>";
echo "dni: <input type='text' name='dni'><br/>";
echo "password: <input type='text' name='pwd'><br/>";
echo "<input type='submit' name='enviar'>";
echo "</form>";